class VideoSystemView {
    constructor() {
        this.main = $('main');
        this.cards = $('#card1');
        this.categories = $('#categories');
    }

    init() {
        this.main.empty();
        this.main.append(`<div class="card-group">
        <a href='#' id='card1'>
        <div class="card">
          <img src="img/accion.jpeg" class="card-img-top" alt="accion">
          </a>
          <div class="card-body">
            <h5 class="card-title">Acción</h5>
            <p class="card-text">Todas las novedades en taquilla de las péliculas con mas acción del momento</p>
            <p class="card-text"><small class="text-muted">Actualizado hace 2 dias</small></p>
          </div>
        </div>
        

        <a href='#' class='card2'>
        <div class="card">
          <img src="img/mafia.jpg" class="card-img-top" alt="humor">
          </a>
          <div class="card-body">
            <h5 class="card-title">Mafia</h5>
            <p class="card-text">Las películas más tronchantes del momento, aquí en exclusiva</p>
            <p class="card-text"><small class="text-muted">Actualizado hace 5 dias</small></p>
          </div>
        </div>
        
        <a href='#' class='card3'>
        <div class="card">
          <img src="img/belicas.jpeg" class="card-img-top" alt="...">
          </a>
          <div class="card-body">
            <h5 class="card-title">Bélicas</h5>
            <p class="card-text">Peliculas basadas en escenarios bélicos, desde clásicos como la Segunda Guerra Mundial a guerras más modernas</p>
            <p class="card-text"><small class="text-muted">Actualizado hace 3 dias</small></p>
          </div>
        </div>
      </div>>`);
    }

    bindInit(handler) {
        $('#init').click((event) => {
            handler();
        });
        $('#logo').click((event) => {
            handler();
        });
    }

    showNumberProductsInCart(numProducts) {
        let spanNumProducts = this.linkShoppingcart.find('span');
        if (spanNumProducts) spanNumProducts.remove();
        if (numProducts > 0) {
            let spanNumProducts = $(` <span class="rounded-circle px-2">${numProducts}</span>`);
            this.linkShoppingcart.append(spanNumProducts);
            this.linkShoppingcart.addClass('shopping');
            this.linkShoppingcart.attr('href', '#shoppingcart-table');
        }
    }

    showMovies() {
        this.main.empty();
        this.main.append(`<div class="card-group">
        <a href='#'>
        <div class="card">
          <img src="img/accion.jpeg" class="card-img-top" alt="accion">
          </a>
          <div class="card-body">
            <h5 class="card-title">Acción</h5>
            <p class="card-text">Todas las novedades en taquilla de las péliculas con mas acción del momento</p>
            <p class="card-text"><small class="text-muted">Actualizado hace 2 dias</small></p>
          </div>
        </div>`);
        alert("HELO");

}


    bindShowMovies(handler) {
        this.cards.click((event) => {
            handler();
        });
    }

}

export default VideoSystemView;
