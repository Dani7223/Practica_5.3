import {
    Person, Category, Resource,
    Production, Movie, Serie,
    User, Coordinate
} from "../entities/productions.js"

class VideoSystemController {
    //Campos privados
    #modelVideoSystem;
    #viewVideoSystem;

    #loadVideoSystemObjects() {
        // //Creamos el objeto para que se almacene
        let p1 = new Person("Alfredo", "James", "Pacino", "25/4/1940", "scarface.jpg");
        // //Creamos el objeto para que se almacene
        let p2 = new Person("Brian", "Russell", "De Palma", "11/9/1940", "scarface.jpg");
        // //Creamos el objeto para que se almacene
        let p3 = new Person("Thomas", "Jeffrey", "Hanks", "9/7/1956", "tom.jpg");
        // //Creamos el objeto para que se almacene
        let p4 = new Person("Steven", "Allan", "Spielberg", "17/2/1965", "spielberg.jpg");
        // //Creamos el objeto para que se almacene
        let p5 = new Person("Jonathan", "Edward", "Bernthal", "20/9/1976", "ben.jpg");
        // //Creamos el objeto para que se almacene
        let p6 = new Person("Stanley", "Martin", "Lieber", "28/12/1922", "stanlee.jpg");
        // //Creamos el objeto para que se almacene
        let c1 = new Category("Mafia", "Las películas de mafia, una versión de las películas de gánsteres, son un subgénero de las películas de crimen");
        // //Creamos el objeto para que se almacene
        let c2 = new Category("Cine bélico", "El cine bélico es el género cinematográfico al que pertenecen las películas y series de televisión cuyo argumento se centra en las guerras");
        // //Creamos el objeto para que se almacene
        let c3 = new Category("Acción", "El llamado cine de acción es un género cinematográfico donde prima la espectacularidad de las imágenes por medio de efectos especiales");
        // //Creamos el objeto para que se almacene
        let r1 = new Resource("2h 50min", "https://www.peliculas/scarface.com");
        // //Creamos el objeto para que se almacene
        let r2 = new Resource("2h 49min", "https://www.peliculas/salvarsoldadoryan.com")
        // //Creamos el objeto para que se almacene
        let r3 = new Resource("23 h", "https://www.series/punisher.com");
        // //Creamos el objeto fuera para que se guarde
        let co1 = new Coordinate(25.77427, -80.19366);
        // //Creamos unas cuantas coordenadas que nos servirán para más tarde
        let co2 = new Coordinate(49.12, -0.43);
        let co3 = new Coordinate(52.52, 13.41);
        let co4 = new Coordinate(40.71427, -74.00597);

        this.#modelVideoSystem.addCategory(c1)
        this.#modelVideoSystem.addCategory(c2)
        this.#modelVideoSystem.addCategory(c3)


    }

    constructor(modelVideoSystem, viewVideoSystem) {
        this.#modelVideoSystem = modelVideoSystem;
        this.#viewVideoSystem = viewVideoSystem;

        // Eventos iniciales del Controlador
        this.onLoad();
        this.onInit();
        // this.onNumberProductsInCartChanged();

        // Enlazamos handlers con la vista
        this.#viewVideoSystem.bindInit(this.handleInit);
        //this.#shoppingCartView.bindInit(this.handleInit.bind(this));
        this.#viewVideoSystem.bindShowMovies(this.handleShowShoppingCart);

    }

    onInit = () => {
        this.#viewVideoSystem.init();
    }



    handleInit = () => {
        this.onInit();
    }

    onLoad = () => {
        this.#loadVideoSystemObjects();
    }

    handleShowShoppingCart = () => {
        this.#viewVideoSystem.showMovies();
    }


    // handleShowShoppingCart = () => {
    //     let data = {
    //         numProducts: this.#shoppingCartModel.getNumberProducts(),
    //         products: this.#shoppingCartModel.products[Symbol.iterator](),
    //         quantities: this.#shoppingCartModel.quantities[Symbol.iterator](),
    //         totalWithoutTaxes: this.#shoppingCartModel.getTotalWithoutTaxes(),
    //         taxes: this.#shoppingCartModel.getTaxes(),
    //         total: this.#shoppingCartModel.getTotal()
    //     }
    //     this.#shoppingCartView.showShoppingCart(data);
    // }

}

export default VideoSystemController;
