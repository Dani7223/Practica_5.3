import { Movie,Serie } from "../entities/productions.js";

class VideoSystemView {
  constructor() {
    this.main = $('main');
    this.cards = $('#card1');
    this.categories = $('#categories');
    this.navbar = $('#navbar');
  }





  init() {
    this.main.empty();
    this.main.append(`
    
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="./img/scarface.jpg" class="d-block mx-auto w-50 h-70" alt="production1">
        <div class="carousel-caption d-none d-md-block">
          <h5>Scarface</h5>
          <p>Increible titulo de mafia</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="./img/soldado.jpg" class="d-block mx-auto w-50 h-70" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5>Second slide label</h5>
          <p>Some representative placeholder content for the second slide.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="./img/padrino.jpg" class="d-block mx-auto w-50 h-70" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5>Third slide label</h5>
          <p>Some representative placeholder content for the third slide.</p>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
  
    
    <br>
    
    <div class="card-group margin" id="categories">
      
        <div class="card m-4" id='card1' >

          <div class="card-body ">
          <a href='#' data-type="Accion">
          <img src="img/accion.jpeg" class="card-img-top" alt="accion">
          
            <h5 class="card-title text-dark">Acción</h5>
            <p class="card-text text-dark">Todas las novedades en taquilla de las péliculas con mas acción del momento</p>
            <p class="card-text text-dark"><small class="text-muted">Actualizado hace 2 dias</small></p>
          </div>
          </a>
        </div>
       
        

        
        <div class="card m-4"  id='card2'>
          <div class="card-body">

          <a href='#' data-type="Mafia">
          <img src="img/mafia.jpg" class="card-img-top" alt="humor">
          </a>
            <h5 class="card-title text-dark">Mafia</h5>
            <p class="card-text text-dark">Todos los contenidos sobre el mundo que rodeaba a las mafias</p>
            <p class="card-text text-dark"><small class="text-muted">Actualizado hace 5 dias</small></p>
         
        </div>
        </div>
       
        
        <div class="card m-4"  id='card3'>

          <div class="card-body">
          <a href='#' data-type="Cine belico">
          <img src="img/belicas.jpeg" class="card-img-top" alt="...">
          </a>
            <h5 class="card-title text-dark">Bélicas</h5>
            <p class="card-text text-dark">Peliculas basadas en escenarios bélicos, desde clásicos como la Segunda Guerra Mundial a guerras más modernas</p>
            <p class="card-text text-dark"><small class="text-muted">Actualizado hace 3 dias</small></p>
          </div>
        </div>
      `);
  }

  bindShowMovies(handler) {
    $('#categories').find('a').click(function (event) {
      handler(this.dataset.type);
    });

  }


  showCategoriesNavbar(categories) {
    let li = $(`<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle text-white" href="#" id="navCats" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Categorías
			</a>
		</li>`);
    let container = $('<div class="dropdown-menu" aria-labelledby="navCats"></div>');

    for (const iterator of categories) {
      container.append(`<a data-category="${iterator.category.name}" class="dropdown-item" href="#productlist">${iterator.category.name}</a>`);
    }
    li.append(container);
    this.navbar.append(li);
  }


  bindProductsCategoryNavbar(handler) {
    $('#navCats').next().children().click(function (event) {
      handler(this.dataset.category);
    })
  }


  showMovies(movies, title) {
    this.main.empty();
    if (this.categories.children().length > 1)
      this.categories.children()[1].remove();
    let container = $("<div id='product-list' class='container my-4'><div id='gap' class='row row-cols-md-2'> </div>");
    let movie = movies.next();
    let type = "";



    while (!movie.done) {

      //Mostramos al lado de la pelicula si es una serie o una pelicula
      if(movie.value instanceof Serie){
        type="Serie";
      }else if(movie.value instanceof Movie){
        type = "Pelicula"
      }

    

      let div = $(`
      <div class="col">
      <figure class='card card-product-grid card-lg'> <a data-serial='${movie.value.title}'  class='img-wrap'><img class='${movie.value.constructor.name}-style rounded mx-auto d-block' src='./img/${movie.value.image}' id='pelis'></a>
      <figcaption class='info-wrap'>
      <div id="peli" class='row'>
        <div id="synopsis" class='col-md-8 text-dark'> <a data-serial='${movie.value.title}' href='#single-product' class='title'>${movie.value.title} - ${type}</a> <br> ${movie.value.synopsis}</div>
        <div class='col-md-4'>
        
          <div class='rating text-right'> <i class='fa fa-star'></i> <i class='fa fa-star'></i> <i class='fa fa-star'></i> </div>
        </div>
      </div>
    </figcaption>


    <div id="watch" class='bottom-wrap'>    
 <a href='#' data-serial='${movie.value.title}' class='btn btn-primary float'> Ver </a>
    </div>
    <div class='price-wrap'> <span class='price h5'>${movie.value.title}</span> <br> <small class='text-success'>Introducida hace poco</small> </div>
  </div>
</figure>
        </div>
      </div>
    `);
      container.children().first().append(div);
      movie = movies.next();
    }
    container.prepend(`<h1>${title}</h1>`);
    this.main.append(container);

  }


  bindInit(handler) {
    $('#init').click((event) => {
      handler();
    });

  }

}

export default VideoSystemView;
