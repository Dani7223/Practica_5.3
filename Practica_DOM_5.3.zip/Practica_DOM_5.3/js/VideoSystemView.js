class VideoSystemView {
  constructor() {
    this.main = $('main');
    this.cards = $('#card1');
    this.categories = $('#categories');
  }

  init() {
    this.main.empty();
    this.main.append(`<div class="card-group margin" id="categories">
        
        <div class="card" id='card1' >
        <a href='#' data-type="Accion">
          <img src="img/accion.jpeg" class="card-img-top" alt="accion">
          </a>
          <div class="card-body">
            <h5 class="card-title">Acción</h5>
            <p class="card-text">Todas las novedades en taquilla de las péliculas con mas acción del momento</p>
            <p class="card-text"><small class="text-muted">Actualizado hace 2 dias</small></p>
          </div>
        </div>
        

        
        <div class="card"  id='card2'>
        <a href='#' data-type="Mafia">
          <img src="img/mafia.jpg" class="card-img-top" alt="humor">
          </a>
          <div class="card-body">
            <h5 class="card-title">Mafia</h5>
            <p class="card-text">Las películas más tronchantes del momento, aquí en exclusiva</p>
            <p class="card-text"><small class="text-muted">Actualizado hace 5 dias</small></p>
          </div>
        </div>
        
       
        <div class="card"  id='card3'>
        <a href='#' data-type="Cine belico">
          <img src="img/belicas.jpeg" class="card-img-top" alt="...">
          </a>
          <div class="card-body">
            <h5 class="card-title">Bélicas</h5>
            <p class="card-text">Peliculas basadas en escenarios bélicos, desde clásicos como la Segunda Guerra Mundial a guerras más modernas</p>
            <p class="card-text"><small class="text-muted">Actualizado hace 3 dias</small></p>
          </div>
        </div>
      </div>`);
  }

  bindShowMovies(handler) {
    $('#categories').find('a').click(function (event) {
      handler(this.dataset.type);
    });

  }



  showMovies(movies, title) {
    this.main.empty();
    if (this.categories.children().length > 1)
      this.categories.children()[1].remove();
    let container = $("<div id='product-list' class='container my-3'><div class='row'> </div></div>");
    let movie = movies.next();
    while (!movie.done) {
      let div = $(`<div class='col-md-4'>
        <figure class='card card-product-grid card-lg'> <a data-serial='${movie.value.title}' href='#single-product' class='img-wrap'><img class='${movie.value.constructor.name}-style' src='./img/${movie.value.image}'></a>
          <figcaption class='info-wrap'>
            <div class='row'>
              <div class='col-md-8'> <a data-serial='${movie.value.title}' href='#single-product' class='title'>${movie.value.brand} - ${movie.value.model}</a> </div>
              <div class='col-md-4'>
                <div class='rating text-right'> <i class='fa fa-star'></i> <i class='fa fa-star'></i> <i class='fa fa-star'></i> </div>
              </div>
            </div>
          </figcaption>
          <div class='bottom-wrap'> <a href='#' data-serial='${movie.value.title}' class='btn btn-primary float-right'> Comprar </a>
            <div class='price-wrap'> <span class='price h5'>${movie.value.title}</span> <br> <small class='text-success'>Free shipping</small> </div>
          </div>
        </figure>
      </div>`);
      container.children().first().append(div);
      movie = movies.next();
    }
    container.prepend(`<h1>${title}</h1>`);
    this.main.append(container);

  }


  bindInit(handler) {
    $('#init').click((event) => {
      handler();
    });

  }

}

export default VideoSystemView;
