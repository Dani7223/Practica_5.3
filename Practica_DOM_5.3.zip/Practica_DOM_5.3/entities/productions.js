"use strict";

//Importamos todas las excepciones
import {
    AbstractClassException, EmptyValueException,
    ExistedElementException, NotExistedElementException,
    InvalidTypeException, InvalidLatitudeException,
    InvalidLongitudeException, InvalidEmailException
}
    from "../js/VideoSystemModel.js";

//Declaramos la validación para el correo electrónico
let validEmail = /^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/;

//Clase person
class Person {
    //Definimos sus propiedades
    #name;
    #lastname1;
    #lastname2;
    #born;
    #picture;

    //Creamos el constructor según si sus propiedades son obligatorias o no
    constructor(name, lastname1, lastname2 = "", born, picture = "") {
        this.#name = name;
        this.#lastname1 = lastname1;
        this.#lastname2 = lastname2;
        this.#born = born;
        this.#picture = picture;

    }


    //Getters de la clase Person(retornamos los valores de la propiedad que queremos)
    get name() {
        return this.#name;
    }

    get lastname1() {
        return this.#lastname1;
    }

    get lastname2() {
        return this.#lastname2;
    }

    get born() {
        return this.#born;
    }

    get picture() {
        return this.#picture;
    }



    //Setters de la clase Person(pasandole por parametro un valor, se lo asignamos a su propiedad)
    set name(value) {
        this.#name = value;
    }

    set lastname1(value) {
        this.#lastname1 = value;
    }

    set lastname2(value) {
        this.#lastname2 = value;
    }

    set born(value) {
        this.#born = value;
    }

    set picture(value) {
        this.#picture = value;
    }

    //Creamos un toString en Person para mostrar sus datos
    toString() {
        return `${this.name} ${this.lastname1} ${this.lastname2} | Nacimiento: ${this.born} | Foto: ${this.picture}`
    }

}

//Clase category
class Category {
    //Definimos sus propiedades
    #name;
    #description;

    //Creamos su constructor
    constructor(name, description = "") {
        this.#name = name;
        this.#description = description;
    }

    //Creamos los getters de Category(retornamos los valores de la propiedad que queremos)
    get name() {
        return this.#name;
    }

    get description() {
        return this.#description;
    }

    //Creamos los setters de Category(pasandole por parametro un valor, se lo asignamos a su propiedad)
    set name(value) {
        this.#name = value;
    }

    set description(value) {
        this.#description = value;
    }

    //Creamos un toString en Category para mostrar sus datos
    toString() {
        return `${this.name}: ${this.description}`
    }
}

//Clase resource que tendrá la película
class Resource {
    //Definimos sus propiedades
    #duration;
    #link;

    //Creamos el constructor según si sus propiedades son obligatorias o no
    constructor(duration, link) {
        this.#duration = duration;
        this.#link = link;
    }

    //Getters de la clase Resource(retornamos los valores de la propiedad que queremos)
    get duration() {
        return this.#duration;
    }

    get link() {
        return this.#link;
    }


    //Setters de la clase Resource(pasandole por parametro un valor, se lo asignamos a su propiedad)
    set duration(value) {
        this.#duration = value;
    }

    set link(value) {
        this.#link = value;
    }


    //Creamos un toString en Resource para mostrar sus datos
    toString() {
        return `Duración: ${this.duration} ---> ${this.link}`
    }


}



class Production {
    //Definimos sus propiedades
    #title;
    #nationality;
    #publication;
    #synopsis;
    #image;


    //Creamos el constructor según si sus propiedades son obligatorias o no
    constructor(title, nationality = "", publication, synopsis = "", image = "") {
        this.#title = title;
        this.#nationality = nationality;
        this.#publication = publication;
        this.#synopsis = synopsis;
        this.#image = image;

        //Si se intenta instanciar un objeto Person nos saltará una excepción de que es abstracto
        if (new.target === Production) throw new AbstractClassException;
    }

    //Getters de la clase Production(retornamos los valores de la propiedad que queremos)
    get title() {
        return this.#title;
    }

    get nationality() {
        return this.#nationality;
    }
    get publication() {
        return this.#publication;
    }

    get synopsis() {
        return this.#synopsis;
    }
    get image() {
        return this.#image;
    }


    //Setters de la clase Production(pasandole por parametro un valor, se lo asignamos a su propiedad)
    set title(value) {
        this.#title = value;
    }

    set nationality(value) {
        this.#nationality = value;
    }

    set publication(value) {
        this.#publication = value;
    }

    set synopsis(value) {
        this.#synopsis = value;
    }

    set image(value) {
        this.#image = value;
    }


    //Creamos un toString en Production para mostrar sus datos
    toString() {
        return `${this.title} | Nacionalidad:${this.nationality} | Fecha publicación:${this.publication} | Sinopsis:${this.synopsis} | Foto:${this.image}`
    }

}




class Movie extends Production {
    //Definimos sus propiedades
    #locations = [];
    #resource;



    //Creamos el constructor según si sus propiedades son obligatorias o no
    constructor(title, nationality = "", publication, synopsis = "", image = "", locations, resource) {
        super(title, nationality, publication, synopsis, image);

        this.#locations = locations;

        if (!(resource instanceof Resource)) throw new InvalidTypeException();

        this.#resource = resource;
    }

    //Getters de la clase Movie(retornamos los valores de la propiedad que queremos)
    get resource() {
        return this.#resource;
    }
    get locations() {
        return this.#locations;
    }


    //Setters de la clase Movie(pasandole por parametro un valor, se lo asignamos a su propiedad)
    set resource(value) {
        this.#resource = value;
    }

    set locations(value) {
        this.#locations = value;
    }

    //Creamos un toString en Production para mostrar sus datos
    toString() {
        return super.toString() + `-->${this.resource} Grabada en: ${this.locations} `
    }

}



class Serie extends Production {
    //Definimos sus propiedades
    #resources;
    #locations;
    #seasons;

    //Creamos el constructor según si sus propiedades son obligatorias o no
    constructor(title, link = "", publication, synopsis = "", image = "", resources = [], locations = [], seasons = 1) {
        super(title, link, publication, synopsis, image);
        this.#resources = resources;
        this.#locations = locations;
        this.#seasons = seasons;

    }

    //Getters de la clase Serie(retornamos los valores de la propiedad que queremos)
    get resources() {
        return this.#resources;
    }
    get locations() {
        return this.#locations;
    }

    get seasons() {
        return this.#seasons;
    }


    //Setters de la clase Serie(pasandole por parametro un valor, se lo asignamos a su propiedad)
    set resources(value) {
        this.#resources = value;
    }

    set locations(value) {
        this.#locations = value;
    }

    set seasons(value) {
        this.#seasons = value;
    }

    //Creamos un toString en Production para mostrar sus datos
    toString() {
        return super.toString() + `-->${this.resources} Grabada en: ${this.locations} Temporadas:${this.seasons} `
    }

}


class User {
    //Definimos sus propiedades
    #username;
    #email;
    #password;

    //Creamos el constructor según si sus propiedades son obligatorias o no
    constructor(username, email, password) {

        //Controlamos que el gmail sea correcto
        if (!(validEmail.test(email))) throw new InvalidEmailException();

        this.#username = username;
        this.#email = email;
        this.#password = password;

    }

    //Getters de la clase User(retornamos los valores de la propiedad que queremos)
    get username() {
        return this.#username;
    }
    get email() {
        return this.#email;
    }

    get password() {
        return this.#password;
    }



    //Setters de la clase User(pasandole por parametro un valor, se lo asignamos a su propiedad)
    set username(value) {
        this.#username = value;
    }

    set email(value) {
        this.#email = value;
    }

    set password(value) {
        this.#password = value;
    }

    //Creamos un toString en Production para mostrar sus datos
    toString() {
        return `${this.username} Correo electrónico: ${this.email} Contraseña:${this.password}`
    }
}


class Coordinate {
    //Definimos sus propiedades
    #latitude;
    #longitude;

    //Creamos el constructor según si sus propiedades son obligatorias o no
    constructor(latitude, longitude) {

        //Controlamos que tanto la latitud como la longitud sean correctas
        if ((latitude > 90) || (latitude < -90)) throw new InvalidLatitudeException();
        this.#latitude = latitude;


        if ((longitude > 180) || (longitude < -180)) throw new InvalidLongitudeException();
        this.#longitude = longitude;

    }

    //Getters de la clase Coordinate(retornamos los valores de la propiedad que queremos)
    get latitude() {
        return this.#latitude;
    }

    get longitude() {
        return this.#longitude;
    }

    //Setters de la clase Coordinate(pasandole por parametro un valor, se lo asignamos a su propiedad)
    set latitude(value) {
        this.#latitude = value;
    }

    set longitude(value) {
        this.#longitude = value;
    }

    //Creamos un toString en Production para mostrar sus datos
    toString() {
        return `Latitud:${this.latitude} Longitud: ${this.longitude}`
    }
}


export {
    Person, Category, Resource,
    Production, Movie, Serie,
    User, Coordinate
}