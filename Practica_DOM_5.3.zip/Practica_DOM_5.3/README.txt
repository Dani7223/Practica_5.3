El carrousel tiene siempre que se recarga la página 3 producciones aleatorias
de todas las que hay, el actor que tiene dos producciones es Alfredo James y 
el enlace de restauración de la página de inicio es el icono negro del menu 